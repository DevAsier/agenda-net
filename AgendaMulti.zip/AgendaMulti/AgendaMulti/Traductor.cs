﻿using System;
using System.Collections.Generic;

namespace AgendaTelefonica
{
    /// <summary>
    /// Gestiona la traducción de textos a diferentes idiomas.
    /// </summary>
    public class Traductor
    {
        private string idioma;
        private static Dictionary<string, Dictionary<string, string>> traducciones = new Dictionary<string, Dictionary<string, string>>()
        {
            { "es", new Dictionary<string, string>
                {
                    { "menu_opciones", "Seleccione una opción:" },
                    { "opcion_agregar", "Agregar contacto" },
                    { "opcion_mostrar", "Mostrar contactos" },
                    { "opcion_salir", "Salir" },
                    { "ingresar_nombre", "Ingrese el nombre del contacto: " },
                    { "ingresar_apellido", "Ingrese el apellido del contacto: " },
                    { "ingresar_telefono", "Ingrese el teléfono del contacto (sin prefijo): " },
                    { "ingresar_fecha", "Ingrese la fecha de nacimiento (dd/MM/yyyy): " },
                    { "contacto_agregado", "Contacto agregado exitosamente." },
                    { "agenda_vacia", "La agenda está vacía." },
                    { "nombre", "Nombre" },
                    { "apellido", "Apellido" },
                    { "telefono", "Teléfono" },
                    { "fecha_nacimiento", "Fecha de nacimiento" },
                    { "id", "ID" },
                    { "error", "Error" }
                }
            },
            { "en", new Dictionary<string, string>
                {
                    { "menu_opciones", "Select an option:" },
                    { "opcion_agregar", "Add contact" },
                    { "opcion_mostrar", "Show contacts" },
                    { "opcion_salir", "Exit" },
                    { "ingresar_nombre", "Enter the contact's name: " },
                    { "ingresar_apellido", "Enter the contact's last name: " },
                    { "ingresar_telefono", "Enter the contact's phone number (without prefix): " },
                    { "ingresar_fecha", "Enter the contact's birth date (dd/MM/yyyy): " },
                    { "contacto_agregado", "Contact successfully added." },
                    { "agenda_vacia", "The agenda is empty." },
                    { "nombre", "Name" },
                    { "apellido", "Last Name" },
                    { "telefono", "Phone Number" },
                    { "fecha_nacimiento", "Date of Birth" },
                    { "id", "ID" },
                    { "error", "Error" }
                }
            },
            { "pt", new Dictionary<string, string>
                {
                    { "menu_opciones", "Selecione uma opção:" },
                    { "opcion_agregar", "Adicionar contato" },
                    { "opcion_mostrar", "Mostrar contatos" },
                    { "opcion_salir", "Sair" },
                    { "ingresar_nombre", "Digite o nome do contato: " },
                    { "ingresar_apellido", "Digite o sobrenome do contato: " },
                    { "ingresar_telefono", "Digite o número de telefone do contato (sem prefixo): " },
                    { "ingresar_fecha", "Digite a data de nascimento do contato (dd/MM/yyyy): " },
                    { "contacto_agregado", "Contato adicionado com sucesso." },
                    { "agenda_vacia", "A agenda está vazia." },
                    { "nombre", "Nome" },
                    { "apellido", "Sobrenome" },
                    { "telefono", "Número de Telefone" },
                    { "fecha_nacimiento", "Data de Nascimento" },
                    { "id", "ID" },
                    { "error", "Erro" }
                }
            }
        };

        /// <summary>
        /// Constructor que inicializa el idioma del traductor.
        /// </summary>
        /// <param name="idioma">Idioma seleccionado.</param>
        public Traductor(string idioma)
        {
            this.idioma = idioma.ToLower();
        }

        /// <summary>
        /// Traduce una clave a un texto en el idioma seleccionado.
        /// </summary>
        /// <param name="clave">Clave del texto a traducir.</param>
        /// <returns>Texto traducido.</returns>
        public string Traducir(string clave)
        {
            if (traducciones.ContainsKey(idioma) && traducciones[idioma].ContainsKey(clave))
            {
                return traducciones[idioma][clave];
            }
            return $"[{clave}]";
        }
    }
}
