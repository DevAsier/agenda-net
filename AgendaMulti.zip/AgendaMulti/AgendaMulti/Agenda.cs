﻿using System;
using System.Collections.Generic;

namespace AgendaTelefonica
{
    /// <summary>
    /// Gestiona una lista de contactos, permitiendo agregar, eliminar, buscar y mostrar contactos.
    /// </summary>
    public class Agenda
    {
        private List<Contacto> contactos;

        /// <summary>
        /// Constructor que inicializa una nueva agenda.
        /// </summary>
        public Agenda()
        {
            contactos = new List<Contacto>();
        }

        /// <summary>
        /// Agrega un contacto a la agenda.
        /// </summary>
        /// <param name="traductor">Traductor para mostrar mensajes en el idioma seleccionado.</param>
        public void AgregarContacto(Traductor traductor)
        {
            Console.Write(traductor.Traducir("ingresar_nombre"));
            string nombre = Console.ReadLine();

            Console.Write(traductor.Traducir("ingresar_apellido"));
            string apellido = Console.ReadLine();

            Console.Write(traductor.Traducir("ingresar_telefono"));
            string telefono = Console.ReadLine();

            Console.Write(traductor.Traducir("ingresar_fecha"));
            string fechaNacimiento = Console.ReadLine();

            try
            {
                var nuevoContacto = new Contacto(nombre, apellido, telefono, fechaNacimiento);
                contactos.Add(nuevoContacto);
                Console.WriteLine(traductor.Traducir("contacto_agregado"));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{traductor.Traducir("error")}: {ex.Message}");
            }
        }

        /// <summary>
        /// Muestra todos los contactos de la agenda.
        /// </summary>
        /// <param name="traductor">Traductor para mostrar mensajes en el idioma seleccionado.</param>
        public void MostrarContactos(Traductor traductor)
        {
            if (contactos.Count == 0)
            {
                Console.WriteLine(traductor.Traducir("agenda_vacia"));
                return;
            }

            foreach (var contacto in contactos)
            {
                Console.WriteLine($"{traductor.Traducir("nombre")}: {contacto.Nombre}");
                Console.WriteLine($"{traductor.Traducir("apellido")}: {contacto.Apellido}");
                Console.WriteLine($"{traductor.Traducir("telefono")}: +34 {contacto.Telefono}");
                Console.WriteLine($"{traductor.Traducir("fecha_nacimiento")}: {contacto.FechaNacimiento}");
                Console.WriteLine($"{traductor.Traducir("id")}: {contacto.ID}");
                Console.WriteLine("-----");
            }
        }
    }
}
