﻿using System;

namespace AgendaTelefonica
{
    /// <summary>
    /// Representa un contacto con información básica.
    /// </summary>
    public class Contacto
    {
        // Propiedades del contacto
        public string Nombre { get; private set; }
        public string Apellido { get; private set; }
        public string Telefono { get; private set; }
        public string FechaNacimiento { get; private set; }
        public Guid ID { get; private set; }

        /// <summary>
        /// Constructor que inicializa un contacto con nombre, apellido, teléfono y fecha de nacimiento.
        /// </summary>
        /// <param name="nombre">Nombre del contacto.</param>
        /// <param name="apellido">Apellido del contacto.</param>
        /// <param name="telefono">Teléfono del contacto (sin prefijo).</param>
        /// <param name="fechaNacimiento">Fecha de nacimiento en formato dd/MM/yyyy.</param>
        public Contacto(string nombre, string apellido, string telefono, string fechaNacimiento)
        {
            if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(apellido))
                throw new ArgumentException("El nombre y el apellido no pueden estar vacíos.");

            if (telefono.Length < 9 || telefono.Length > 12)
                throw new ArgumentException("El teléfono debe tener entre 9 y 12 caracteres.");

            if (!DateTime.TryParseExact(fechaNacimiento, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out _))
                throw new ArgumentException("La fecha de nacimiento debe estar en el formato dd/MM/yyyy.");

            Nombre = nombre;
            Apellido = apellido;
            Telefono = telefono;
            FechaNacimiento = fechaNacimiento;
            ID = Guid.NewGuid(); // Generar un identificador único
        }
    }
}
