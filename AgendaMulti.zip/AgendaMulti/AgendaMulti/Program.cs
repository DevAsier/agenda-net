﻿using System;

namespace AgendaTelefonica
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Seleccione idioma: ES, EN, PT");
            string idioma = Console.ReadLine();

            var traductor = new Traductor(idioma);
            var agenda = new Agenda();

            bool salir = false;

            while (!salir)
            {
                Console.WriteLine(traductor.Traducir("menu_opciones"));
                Console.WriteLine("1. " + traductor.Traducir("opcion_agregar"));
                Console.WriteLine("2. " + traductor.Traducir("opcion_mostrar"));
                Console.WriteLine("3. " + traductor.Traducir("opcion_salir"));

                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        agenda.AgregarContacto(traductor);
                        break;
                    case "2":
                        agenda.MostrarContactos(traductor);
                        break;
                    case "3":
                        salir = true;
                        break;
                    default:
                        Console.WriteLine(traductor.Traducir("error"));
                        break;
                }
            }
        }
    }
}
